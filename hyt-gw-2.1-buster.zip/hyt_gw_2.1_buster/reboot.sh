sleep 20
killall svxlink > none
/usr/bin/screen -dmS SVXLINK svxlink
sleep 1
cd /opt/get_serial
/usr/bin/screen -dmS DTMF ./tetra_serial_client.py
